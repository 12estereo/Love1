package com.miaivideo.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE=41;
    private static final String PREF="mi_ai_video_private";
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private EditText prompt,keyInput;
    private TextView status,imageStatus;
    private Uri selectedImage;
    private String mode="Texto a video";
    private Button generate;
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView txt(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF10101A);getWindow().setNavigationBarColor(0xFF10101A);
        ScrollView sc=new ScrollView(this);sc.setBackgroundColor(0xFF10101A);LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(dp(20),dp(24),dp(20),dp(28));sc.addView(p);
        TextView title=txt("MI AI VIDEO",30,Color.WHITE);title.setGravity(Gravity.CENTER);title.setTypeface(null,1);p.addView(title);
        TextView sub=txt("Crea videos con inteligencia artificial",15,Color.LTGRAY);sub.setGravity(Gravity.CENTER);p.addView(sub);
        Button key=btn("🔐  CONFIGURAR MI API KEY");p.addView(key);key.setOnClickListener(v->keyDialog());
        TextView ml=txt("TIPO DE CREACIÓN",13,0xFFB9A7FF);ml.setPadding(0,dp(18),0,dp(6));p.addView(ml);
        LinearLayout modes=new LinearLayout(this);Button t=btn("Texto a video"),im=btn("Imagen a video");modes.addView(t,new LinearLayout.LayoutParams(0,-2,1));modes.addView(im,new LinearLayout.LayoutParams(0,-2,1));p.addView(modes);
        t.setOnClickListener(v->{mode="Texto a video";t.setAlpha(1f);im.setAlpha(.65f);});im.setOnClickListener(v->{mode="Imagen a video";im.setAlpha(1f);t.setAlpha(.65f);});im.setAlpha(.65f);
        TextView pl=txt("DESCRIBE EL VIDEO QUE QUIERES",13,0xFFB9A7FF);pl.setPadding(0,dp(18),0,dp(6));p.addView(pl);
        prompt=new EditText(this);prompt.setTextColor(Color.WHITE);prompt.setHintTextColor(0xFF9999A8);prompt.setHint("Ejemplo: Un paisaje colombiano al atardecer, cámara cinematográfica...");prompt.setMinLines(4);prompt.setGravity(Gravity.TOP);prompt.setPadding(dp(12),dp(12),dp(12),dp(12));prompt.setBackgroundColor(0xFF29283A);p.addView(prompt,new LinearLayout.LayoutParams(-1,dp(120)));
        Button choose=btn("＋  Elegir imagen");p.addView(choose);imageStatus=txt("Ninguna imagen seleccionada",12,Color.LTGRAY);p.addView(imageStatus);choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_IMAGE);});
        TextView conf=txt("CONFIGURACIÓN\n720p HD  ·  Vertical 9:16  ·  5 segundos",14,Color.WHITE);conf.setPadding(dp(12),dp(16),dp(12),dp(16));conf.setBackgroundColor(0xFF29283A);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(18),0,0);p.addView(conf,cp);
        generate=btn("GENERAR VIDEO CON IA");generate.setTextColor(Color.WHITE);generate.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF7047D7));LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(56));gp.setMargins(0,dp(18),0,dp(10));p.addView(generate,gp);generate.setOnClickListener(v->startGeneration());
        status=txt("Listo para crear. Configura tu API Key para comenzar.",13,0xFFD5D2E5);status.setGravity(Gravity.CENTER);p.addView(status);
        TextView foot=txt("Modelo Agnes Video 2.5 Flash · 720P",11,0xFF9C9CAD);foot.setGravity(Gravity.CENTER);p.addView(foot);setContentView(sc);
    }
    private void keyDialog(){LinearLayout box=new LinearLayout(this);box.setPadding(dp(8),dp(4),dp(8),dp(4));box.setOrientation(1);TextView help=txt("Pega aquí tu API Key nueva. Se guarda solo en el almacenamiento privado de esta aplicación; no se incluye en el ZIP ni en GitHub.",13,Color.DKGRAY);box.addView(help);keyInput=new EditText(this);keyInput.setSingleLine(true);keyInput.setHint("API Key de Agnes AI");keyInput.setInputType(129);keyInput.setText(getSharedPreferences(PREF,0).getString("api_key",""));box.addView(keyInput);new AlertDialog.Builder(this).setTitle("Configurar Agnes AI").setView(box).setNegativeButton("Cancelar",null).setNeutralButton("Borrar clave",(d,w)->{getSharedPreferences(PREF,0).edit().remove("api_key").apply();Toast.makeText(this,"Clave borrada del teléfono",Toast.LENGTH_SHORT).show();}).setPositiveButton("Guardar",(d,w)->{String k=keyInput.getText().toString().trim();if(!k.isEmpty())getSharedPreferences(PREF,0).edit().putString("api_key",k).apply();Toast.makeText(this,"Clave guardada en este teléfono",Toast.LENGTH_SHORT).show();}).show();}
    private void startGeneration(){String text=prompt.getText().toString().trim();String api=getSharedPreferences(PREF,0).getString("api_key","");if(api.isEmpty()){keyDialog();return;}if(text.isEmpty()){prompt.setError("Escribe una descripción");return;}if(mode.equals("Imagen a video")&&selectedImage==null){new AlertDialog.Builder(this).setMessage("Selecciona una imagen para animarla.").setPositiveButton("OK",null).show();return;}generate.setEnabled(false);status.setText("Enviando solicitud a Agnes AI...");worker.execute(()->generateAndWait(api,text));}
    private JSONObject request(String endpoint,String method,String key,JSONObject body)throws Exception{URL u=new URL("https://apihub.agnes-ai.com"+endpoint);HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod(method);c.setConnectTimeout(30000);c.setReadTimeout(60000);c.setRequestProperty("Authorization","Bearer "+key);c.setRequestProperty("Content-Type","application/json");if(body!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes("UTF-8"));}}int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String response=read(in);c.disconnect();if(code<200||code>=300)throw new Exception("Agnes AI respondió HTTP "+code+": "+response);return new JSONObject(response);}
    private String read(InputStream in)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return b.toString("UTF-8");}
    private void update(String s){runOnUiThread(()->status.setText(s));}
    private void generateAndWait(String key,String description){try{JSONObject body=new JSONObject();body.put("model","agnes-video-2.5-flash");body.put("prompt",description);body.put("mode",mode.equals("Texto a video")?"text":"img2video");body.put("seconds","5");body.put("size","720P");body.put("aspect_ratio","9:16");body.put("n",1);if(mode.equals("Imagen a video")){String mime=getContentResolver().getType(selectedImage);if(mime==null)mime="image/jpeg";byte[] data;try(InputStream in=getContentResolver().openInputStream(selectedImage)){data=readBytes(in,8*1024*1024);}String dataUri="data:"+mime+";base64,"+Base64.encodeToString(data,Base64.NO_WRAP);body.put("first_frame",dataUri);}
        JSONObject created=request("/v1/videos","POST",key,body);String id=created.optString("video_id","");if(id.isEmpty())id=created.optString("id","");if(id.isEmpty())throw new Exception("Agnes no devolvió video_id. Respuesta: "+created);final String videoId=id;update("Solicitud recibida. Generando video... ID: "+id);
        for(int i=0;i<60;i++){Thread.sleep(10000);String path="/agnesapi?video_id="+URLEncoder.encode(videoId,"UTF-8")+"&model_name=agnes-video-2.5-flash";JSONObject poll=request(path,"GET",key,null);String st=poll.optString("status","");int progress=poll.optInt("progress",-1);update("Generando tu video... "+(progress>=0?progress+"%":st));if("failed".equalsIgnoreCase(st))throw new Exception("La generación falló: "+poll.optString("error","Error desconocido"));if("completed".equalsIgnoreCase(st)){String video=poll.optString("url","");if(video.isEmpty())throw new Exception("El servicio terminó pero no entregó el enlace MP4.");download(video);return;}}
        throw new Exception("La generación sigue en proceso. Intenta consultar más tarde; ID: "+videoId);
      }catch(Exception e){update("Error: "+e.getMessage());}finally{runOnUiThread(()->generate.setEnabled(true));}}
    private byte[] readBytes(InputStream in,int max)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(b.size()+n>max)throw new Exception("La imagen supera 8 MB. Elige una imagen más ligera.");b.write(buf,0,n);}return b.toByteArray();}
    private void download(String url){try{DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));r.setTitle("MI AI VIDEO - video generado");r.setDescription("Descargando tu video MP4");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES,"MIAIVideo_"+System.currentTimeMillis()+".mp4");DownloadManager dm=(DownloadManager)getSystemService(DOWNLOAD_SERVICE);dm.enqueue(r);update("¡Video generado! Descarga iniciada. Busca el MP4 en la carpeta Movies.");runOnUiThread(()->new AlertDialog.Builder(this).setTitle("¡Video listo!").setMessage("Tu video se está descargando en la carpeta Movies del teléfono.").setPositiveButton("Genial",null).show());}catch(Exception e){update("Video generado, pero falló la descarga: "+e.getMessage());}}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_IMAGE&&c==RESULT_OK&&d!=null){selectedImage=d.getData();if(selectedImage!=null){try{getContentResolver().takePersistableUriPermission(selectedImage,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}imageStatus.setText("Imagen seleccionada correctamente");}}}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdown();}
}
